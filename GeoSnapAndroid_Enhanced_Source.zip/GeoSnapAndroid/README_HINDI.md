# GeoSnap Android — फोन से APK बनाने वाला source project

यह Android source project है, तैयार APK नहीं। इसमें ये सुविधाएँ हैं:
- Camera preview और photo capture
- फोटो पर address/location, GPS coordinates, date और time stamp
- फोटो अपने-आप Gallery के `Pictures/GeoSnap` folder में save करना
- Android share sheet से फोटो साझा करना
- Front/back camera switch
- Live location sharing का UI/service skeleton (इसे चलाने के लिए Firebase setup ज़रूरी है)
- GitHub Actions workflow, जो cloud में debug APK बनाकर downloadable artifact देता है

## बहुत ज़रूरी बात
- ZIP को APK की तरह install नहीं किया जा सकता।
- ZIP का आकार 20–25 MB करना ज़रूरी नहीं है। APK का आकार build, Android libraries और included assets पर निर्भर करता है। फ़ाइल को बेकार data से बड़ा करना उपयोगी नहीं है।
- इस source project को यहाँ Android SDK के साथ build/test नहीं किया गया है; cloud build में error आए तो workflow logs देखकर सुधार करना होगा।
- Live location sharing अभी Firebase configuration के बिना काम नहीं करेगी। Photos/GPS stamp features अलग से इस्तेमाल किए जा सकते हैं।
- Public Firebase database rules का इस्तेमाल न करें। Live sharing चालू करने से पहले Firebase Authentication और session-specific secure rules लगाएँ।

## बिना PC के फोन से APK बनाना
1. ZIP को फोन में डाउनलोड करें और file manager से extract करें।
2. GitHub पर अपना repository खोलें। ZIP फ़ाइल को Copilot में upload न करें। Repository में extracted project की files/folders upload करें, जिसमें `.github/workflows/android.yml` भी शामिल हो। ध्यान दें: hidden `.github` folder दिखाने के लिए file manager में “Show hidden files” चालू करना पड़ सकता है।
3. Repository की branch का नाम `main` हो।
4. GitHub repository में **Actions** tab खोलें। `Build GeoSnap APK` workflow चुनकर **Run workflow** दबाएँ।
5. Build सफल होने पर run खोलें, नीचे **Artifacts** में `GeoSnap-debug-APK` डाउनलोड करें। यह ZIP artifact के अंदर `app-debug.apk` होगा। Artifact ZIP को extract करें, फिर APK install करें।
6. Android अगर अनुमति माँगे, तो सिर्फ तभी “Install unknown apps” अनुमति दें जब आपने artifact अपने सही repository के सफल build से डाउनलोड किया हो।

## Build details
- Package: `com.divergentfact.geosnap`
- Min Android: 8.0 (API 26)
- Java: 17
- Android Gradle Plugin: 8.7.3; Gradle: 8.9

## Live location Firebase setup
Firebase project, Realtime Database URL, app configuration, hosting viewer URL और production-secure database rules सेट किए बिना live location feature पूर्ण नहीं है। इसे public read/write database के साथ deploy न करें।
